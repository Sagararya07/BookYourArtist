'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState, useEffect } from 'react';
import { FaBars, FaTimes } from 'react-icons/fa';
import styles from './Header.module.css';

const navLinks = [
  { href: '/', label: 'Home' },
  { href: '/about', label: 'About Us' },
  { href: '/artists', label: 'Artists Booking' },
];

export default function Header() {
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Close menu on route change
  useEffect(() => {
    setMenuOpen(false);
  }, [pathname]);

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`}>
      <div className={styles.inner}>
        {/* Left nav */}
        <nav className={`${styles.nav} ${styles.navLeft}`}>
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`${styles.navLink} ${pathname === link.href ? styles.active : ''}`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Logo (center) */}
        <Link href="/" className={styles.logo}>
          <span className={styles.logoText}>BookYour<span className={styles.logoAccent}>Artist</span></span>
        </Link>

        {/* Right nav */}
        <div className={`${styles.nav} ${styles.navRight}`}>
          <Link
            href="/contact"
            className={`${styles.navLink} ${pathname === '/contact' ? styles.active : ''}`}
          >
            Contact Us
          </Link>
          <Link href="/artists" className={`btn btn-primary btn-sm ${styles.ctaBtn}`}>
            Let&apos;s Have a Quick Discussion
          </Link>
        </div>

        {/* Mobile hamburger */}
        <button
          className={styles.hamburger}
          onClick={() => setMenuOpen((p) => !p)}
          aria-label="Toggle menu"
        >
          {menuOpen ? <FaTimes /> : <FaBars />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className={styles.mobileMenu}>
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`${styles.mobileLink} ${pathname === link.href ? styles.active : ''}`}
            >
              {link.label}
            </Link>
          ))}
          <Link
            href="/contact"
            className={`${styles.mobileLink} ${pathname === '/contact' ? styles.active : ''}`}
          >
            Contact Us
          </Link>
          <Link href="/artists" className="btn btn-primary btn-sm w-full" style={{ justifyContent: 'center', marginTop: '8px' }}>
            Let&apos;s Have a Quick Discussion
          </Link>
        </div>
      )}
    </header>
  );
}
