'use client';

import { useState } from 'react';
import { FaPhoneAlt, FaEnvelope, FaMapMarkerAlt, FaWhatsapp, FaCheckCircle } from 'react-icons/fa';

export default function ContactPage() {
  const [form, setForm] = useState({ name: '', phone: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((p) => ({ ...p, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (data.success) {
        setSuccess(true);
        setForm({ name: '', phone: '', message: '' });
      } else {
        setError(data.error || 'Something went wrong.');
      }
    } catch {
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* PAGE HEADER */}
      <section className="bg-[#0a0a0f] pt-32 pb-12 border-b border-[rgba(255,255,255,0.05)]">
        <div className="container text-center">
          <span className="section-tag animate-fadeIn">Get In Touch</span>
          <h1 className="font-display text-4xl md:text-5xl font-bold text-white mt-4 mb-4">Contact Us</h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Have a question? Need help choosing an artist? Reach out to our team and we'll get back to you immediately.
          </p>
        </div>
      </section>

      <section className="section bg-[#10101a] relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-[rgba(212,168,67,0.05)] via-transparent to-transparent"></div>
        <div className="container relative z-10">
          <div className="grid md:grid-cols-2 gap-12 lg:gap-20">
            
            {/* CONTACT DETAILS */}
            <div>
              <h2 className="font-display text-3xl font-bold text-white mb-8">Our Office</h2>
              
              <div className="flex flex-col gap-8 mb-12">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-[#1a1a2e] flex items-center justify-center text-[#d4a843] shrink-0 border border-[#d4a843]/30">
                    <FaMapMarkerAlt className="text-xl" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-white mb-1">Mumbai Headquarters</h4>
                    <p className="text-gray-400 leading-relaxed">
                      BookYourArtist India<br />
                      Mumbai, Maharashtra 400001<br />
                      India
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-[#1a1a2e] flex items-center justify-center text-[#d4a843] shrink-0 border border-[#d4a843]/30">
                    <FaPhoneAlt className="text-xl" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-white mb-1">Phone / WhatsApp</h4>
                    <a href="tel:+919353548082" className="block text-gray-400 hover:text-[#d4a843] transition-colors mb-1">+91 93535 48082</a>
                    <a href="https://wa.me/919353548082" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-[#25d366] hover:text-white transition-colors text-sm font-medium mt-1">
                      <FaWhatsapp /> Chat on WhatsApp
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-[#1a1a2e] flex items-center justify-center text-[#d4a843] shrink-0 border border-[#d4a843]/30">
                    <FaEnvelope className="text-xl" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-white mb-1">Email Address</h4>
                    <a href="mailto:sagarsagar49061@gmail.com" className="text-gray-400 hover:text-[#d4a843] transition-colors">sagarsagar49061@gmail.com</a>
                  </div>
                </div>
              </div>

              {/* MAP PLACEHOLDER */}
              <div className="w-full h-64 rounded-xl overflow-hidden border border-[rgba(255,255,255,0.1)] relative group">
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-10 group-hover:bg-black/30 transition-colors">
                  <a href="https://maps.google.com/?q=Mumbai+Maharashtra+400001" target="_blank" rel="noreferrer" className="btn btn-secondary">Open in Google Maps</a>
                </div>
                <img 
                  src="https://images.unsplash.com/photo-1524492412937-b28074a5d7da?q=80&w=1000&auto=format&fit=crop" 
                  alt="Mumbai Map" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* CONTACT FORM */}
            <div className="card-glass p-8 md:p-10 shadow-[0_8px_32px_rgba(0,0,0,0.5)]">
              <h2 className="font-display text-2xl font-bold text-white mb-2">Send us a Message</h2>
              <p className="text-gray-400 mb-8 text-sm">We reply to all inquiries within 2-4 hours.</p>

              {success ? (
                <div className="text-center py-10 animate-fadeIn">
                  <FaCheckCircle className="text-5xl text-[#22c55e] mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-white mb-2">Message Sent!</h3>
                  <p className="text-gray-400 mb-6">Thanks for reaching out. Our team will get back to you shortly.</p>
                  <button onClick={() => setSuccess(false)} className="btn btn-secondary w-full">Send Another Message</button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                  {error && <div className="alert alert-error">{error}</div>}
                  
                  <div className="form-group mb-0">
                    <label className="form-label text-white/80">Your Name *</label>
                    <input 
                      name="name" 
                      className="form-control bg-black/40 border-white/10" 
                      placeholder="John Doe" 
                      value={form.name} 
                      onChange={handleChange} 
                      required 
                    />
                  </div>
                  
                  <div className="form-group mb-0">
                    <label className="form-label text-white/80">Phone Number *</label>
                    <input 
                      name="phone" 
                      className="form-control bg-black/40 border-white/10" 
                      placeholder="+91 XXXXX XXXXX" 
                      value={form.phone} 
                      onChange={handleChange} 
                      required 
                    />
                  </div>
                  
                  <div className="form-group mb-0">
                    <label className="form-label text-white/80">Message *</label>
                    <textarea 
                      name="message" 
                      className="form-control bg-black/40 border-white/10" 
                      placeholder="How can we help you?" 
                      value={form.message} 
                      onChange={handleChange} 
                      rows={5}
                      required 
                    />
                  </div>
                  
                  <button type="submit" className="btn btn-primary w-full mt-2" disabled={loading}>
                    {loading ? 'Sending...' : 'Send Message'}
                  </button>
                </form>
              )}
            </div>

          </div>
        </div>
      </section>
    </>
  );
}
