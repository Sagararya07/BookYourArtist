import { Metadata } from 'next';
import Link from 'next/link';
import { FaTrophy, FaUsers, FaGlobe, FaHandshake, FaMusic, FaCheckCircle } from 'react-icons/fa';

export const metadata: Metadata = {
  title: 'About Us',
  description: 'Learn about BookYourArtist, India\'s premier platform for booking verified artists for weddings, corporate events, and parties.',
};

export default function AboutPage() {
  return (
    <>
      {/* PAGE HEADER */}
      <section className="relative pt-32 pb-20 overflow-hidden border-b border-[rgba(255,255,255,0.05)]">
        <div className="absolute inset-0 bg-gradient-to-b from-[#10101a] to-[#0a0a0f] z-0"></div>
        <div className="container relative z-10 text-center">
          <span className="section-tag animate-fadeIn">About BookYourArtist</span>
          <h1 className="font-display text-4xl md:text-6xl font-bold text-white mt-4 mb-6 animate-slideUp">
            Elevating Your Events With<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#d4a843] to-[#f0c060]">
              World-Class Talent
            </span>
          </h1>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto leading-relaxed animate-slideUp" style={{ animationDelay: '0.2s' }}>
            We are India's premier entertainment booking platform, connecting event organizers, couples, and corporate hosts with top-tier artists. We make the booking process transparent, professional, and completely hassle-free.
          </p>
        </div>
      </section>

      {/* MISSION & VISION */}
      <section className="section bg-[#0a0a0f]">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1 relative h-[500px] rounded-2xl overflow-hidden border border-[#d4a843]/20 shadow-[0_0_40px_rgba(212,168,67,0.15)]">
              <img 
                src="https://images.unsplash.com/photo-1540039155732-d68a9235e236?q=80&w=1000&auto=format&fit=crop" 
                alt="Stage Performance" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
              <div className="absolute bottom-8 left-8 right-8">
                <div className="bg-black/60 backdrop-blur-md border border-white/10 p-6 rounded-xl">
                  <p className="text-lg font-serif italic text-white">
                    "Our goal is to make world-class entertainment accessible to every stage in India."
                  </p>
                </div>
              </div>
            </div>

            <div className="order-1 md:order-2">
              <div className="mb-12">
                <h2 className="font-display text-3xl font-bold text-white mb-4 flex items-center gap-4">
                  <span className="w-10 h-10 rounded-full bg-[#1a1a2e] flex items-center justify-center text-[#d4a843] border border-[#d4a843]/30">01</span>
                  Our Mission
                </h2>
                <p className="text-gray-300 leading-relaxed pl-14 border-l border-[#2a2a3e] ml-5 py-2">
                  To solve the unorganized artist booking industry by providing a transparent, trusted, and efficient platform where clients can easily discover, connect with, and book premium verified talent without hidden fees or unprofessional delays.
                </p>
              </div>

              <div>
                <h2 className="font-display text-3xl font-bold text-white mb-4 flex items-center gap-4">
                  <span className="w-10 h-10 rounded-full bg-[#1a1a2e] flex items-center justify-center text-[#d4a843] border border-[#d4a843]/30">02</span>
                  Our Vision
                </h2>
                <p className="text-gray-300 leading-relaxed pl-14 border-l border-[#2a2a3e] ml-5 py-2">
                  To become the global standard for event entertainment booking, scaling our network to feature thousands of artists across the world, ensuring that no stage remains empty and no event is anything less than spectacular.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US (Detailed) */}
      <section className="section bg-[#10101a] border-y border-[rgba(255,255,255,0.05)]">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="section-title">Why Choose BookYourArtist?</h2>
            <div className="divider-gold"></div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="card-glass p-8 flex flex-col hover:border-[#d4a843]/50 transition-colors">
              <FaCheckCircle className="text-4xl text-[#d4a843] mb-6" />
              <h3 className="text-xl font-bold text-white mb-3">Verified Professionalism</h3>
              <p className="text-gray-400 leading-relaxed">
                Every artist on our platform undergoes a strict vetting process. We check their past performances, client reviews, and professionalism before onboarding them.
              </p>
            </div>

            <div className="card-glass p-8 flex flex-col hover:border-[#d4a843]/50 transition-colors">
              <FaHandshake className="text-4xl text-[#d4a843] mb-6" />
              <h3 className="text-xl font-bold text-white mb-3">Transparent Pricing</h3>
              <p className="text-gray-400 leading-relaxed">
                No hidden charges or last-minute surprises. We discuss the budget upfront and ensure you get the best talent within your financial requirements.
              </p>
            </div>

            <div className="card-glass p-8 flex flex-col hover:border-[#d4a843]/50 transition-colors">
              <FaMusic className="text-4xl text-[#d4a843] mb-6" />
              <h3 className="text-xl font-bold text-white mb-3">End-to-End Management</h3>
              <p className="text-gray-400 leading-relaxed">
                From the first inquiry to the final applause, our dedicated event managers handle the artist coordination so you can focus on enjoying your event.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* STATS / TRUST ELEMENTS */}
      <section className="py-24 relative overflow-hidden bg-black border-b border-[rgba(255,255,255,0.05)]">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1492684223066-81342ee5ff30?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center opacity-20 blur-[2px]"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-black"></div>
        
        <div className="container relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-4 text-center">
            <div>
              <FaUsers className="text-5xl text-[#d4a843] mx-auto mb-4" />
              <div className="text-4xl md:text-5xl font-display font-bold text-white mb-2">5,000+</div>
              <div className="text-gray-400 uppercase tracking-widest text-sm font-bold">Events Handled</div>
            </div>
            
            <div>
              <FaMusic className="text-5xl text-[#d4a843] mx-auto mb-4" />
              <div className="text-4xl md:text-5xl font-display font-bold text-white mb-2">800+</div>
              <div className="text-gray-400 uppercase tracking-widest text-sm font-bold">Verified Artists</div>
            </div>
            
            <div>
              <FaGlobe className="text-5xl text-[#d4a843] mx-auto mb-4" />
              <div className="text-4xl md:text-5xl font-display font-bold text-white mb-2">25+</div>
              <div className="text-gray-400 uppercase tracking-widest text-sm font-bold">Cities Covered</div>
            </div>
            
            <div>
              <FaTrophy className="text-5xl text-[#d4a843] mx-auto mb-4" />
              <div className="text-4xl md:text-5xl font-display font-bold text-white mb-2">4.9/5</div>
              <div className="text-gray-400 uppercase tracking-widest text-sm font-bold">Client Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* TEAM SECTION */}
      <section className="section bg-[#0a0a0f]">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="section-title">The Minds Behind The Magic</h2>
            <div className="divider-gold"></div>
          </div>

          <div className="grid md:grid-cols-3 gap-10">
            {/* Team Member 1 */}
            <div className="group text-center">
              <div className="relative w-48 h-48 mx-auto rounded-full overflow-hidden mb-6 border-2 border-[#1a1a2e] group-hover:border-[#d4a843] transition-colors duration-300">
                <img 
                  src="https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=400&auto=format&fit=crop" 
                  alt="Sagar R - Founder" 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500"
                />
              </div>
              <h3 className="text-xl font-bold text-white mb-1">Sagar R.</h3>
              <p className="text-[#d4a843] font-medium text-sm tracking-wider uppercase mb-3">Founder & CEO</p>
              <p className="text-gray-400 text-sm">Visionary entrepreneur with a passion for transforming the Indian entertainment booking landscape.</p>
            </div>

            {/* Team Member 2 */}
            <div className="group text-center">
              <div className="relative w-48 h-48 mx-auto rounded-full overflow-hidden mb-6 border-2 border-[#1a1a2e] group-hover:border-[#d4a843] transition-colors duration-300">
                <img 
                  src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=400&auto=format&fit=crop" 
                  alt="Priya Singh - Head of Operations" 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500"
                />
              </div>
              <h3 className="text-xl font-bold text-white mb-1">Priya Singh</h3>
              <p className="text-[#d4a843] font-medium text-sm tracking-wider uppercase mb-3">Head of Operations</p>
              <p className="text-gray-400 text-sm">Ensuring flawless execution of every event and maintaining our strict quality standards.</p>
            </div>

            {/* Team Member 3 */}
            <div className="group text-center">
              <div className="relative w-48 h-48 mx-auto rounded-full overflow-hidden mb-6 border-2 border-[#1a1a2e] group-hover:border-[#d4a843] transition-colors duration-300">
                <img 
                  src="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=400&auto=format&fit=crop" 
                  alt="Karan Mehta - Artist Relations" 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500"
                />
              </div>
              <h3 className="text-xl font-bold text-white mb-1">Karan Mehta</h3>
              <p className="text-[#d4a843] font-medium text-sm tracking-wider uppercase mb-3">Head of Artist Relations</p>
              <p className="text-gray-400 text-sm">The bridge between our platform and the incredible talent network across India.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA SECTION */}
      <section className="py-16 bg-[#14141f] border-t border-[rgba(255,255,255,0.05)] text-center">
        <div className="container">
          <h2 className="font-display text-3xl font-bold text-white mb-6">Want to Join Our Artist Network?</h2>
          <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
            Are you a professional artist looking to perform at premium events? Get in touch with our Artist Relations team.
          </p>
          <Link href="/contact" className="btn btn-secondary btn-lg">
            Contact Our Team
          </Link>
        </div>
      </section>
    </>
  );
}
