import type { Metadata } from 'next';
import './globals.css';
import Header from '@/components/Header/Header';
import Footer from '@/components/Footer/Footer';
import FloatingContact from '@/components/FloatingContact/FloatingContact';

export const metadata: Metadata = {
  title: {
    default: 'BookYourArtist — Book Top Artists for Your Events',
    template: '%s | BookYourArtist',
  },
  description:
    'Book top-rated DJs, Singers, Dancers, Comedians, Bands and more for weddings, corporate events, birthday parties and college fests across India. Mumbai-based artist booking platform.',
  keywords: [
    'artist booking india',
    'book dj for wedding',
    'singer for event mumbai',
    'event entertainment india',
    'book artist online',
    'bookyourartist',
  ],
  authors: [{ name: 'BookYourArtist' }],
  creator: 'BookYourArtist',
  openGraph: {
    type: 'website',
    locale: 'en_IN',
    siteName: 'BookYourArtist',
    title: 'BookYourArtist — Book Top Artists for Your Events',
    description:
      'Book verified, top-rated artists for any event across India. Fast booking, responsive team.',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'BookYourArtist — Book Top Artists for Your Events',
    description: 'Book DJs, Singers, Dancers, Comedians & more for your events across India.',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
        <Header />
        <main style={{ flex: 1, paddingTop: 'var(--header-height)' }}>
          {children}
        </main>
        <Footer />
        <FloatingContact />
      </body>
    </html>
  );
}
