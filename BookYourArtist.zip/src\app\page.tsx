'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { FaCheckCircle, FaStar, FaMusic, FaGlassCheers, FaBuilding, FaGraduationCap } from 'react-icons/fa';
import BookingModal from '@/components/BookingModal/BookingModal';

export default function Home() {
  const [featuredArtists, setFeaturedArtists] = useState<any[]>([]);
  const [testimonials, setTestimonials] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedArtist, setSelectedArtist] = useState<{ id?: number; name?: string } | null>(null);

  useEffect(() => {
    async function fetchData() {
      try {
        const [artistsRes] = await Promise.all([
          fetch('/api/artists?featured=true')
        ]);
        const artistsData = await artistsRes.json();
        if (artistsData.success) {
          setFeaturedArtists(artistsData.data.slice(0, 4)); // Only show top 4
        }
        
        // Use hardcoded testimonials for now as we don't have an API for them yet
        setTestimonials([
          {
            id: 1,
            name: 'Anita Desai',
            role: 'Wedding Client',
            content: 'BookYourArtist made our wedding absolutely unforgettable! DJ Arjun kept everyone on the dance floor all night.',
            rating: 5,
          },
          {
            id: 2,
            name: 'Rajesh Kumar',
            role: 'Corporate Event Manager',
            content: 'We booked Rahul Verma for our annual corporate night. He had 300 employees laughing non-stop!',
            rating: 5,
          },
          {
            id: 3,
            name: 'Pooja Mehta',
            role: 'Birthday Party Host',
            content: 'The Rhythm Band was simply outstanding at my 30th birthday bash. Will definitely book again!',
            rating: 5,
          }
        ]);
      } catch (err) {
        console.error('Failed to fetch home data:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const openBooking = (artist?: any) => {
    if (artist) {
      setSelectedArtist({ id: artist.id, name: artist.name });
    } else {
      setSelectedArtist(null);
    }
    setModalOpen(true);
  };

  return (
    <>
      {/* HERO SECTION */}
      <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-[#0a0a0f] z-10" />
          <img 
            src="https://images.unsplash.com/photo-1492684223066-81342ee5ff30?q=80&w=2070&auto=format&fit=crop" 
            alt="Live Concert" 
            className="w-full h-full object-cover animate-pulse"
            style={{ animationDuration: '10s' }}
          />
        </div>

        <div className="container relative z-10 flex flex-col items-center text-center mt-xl">
          <span className="section-tag animate-fadeIn" style={{ animationDelay: '0.2s' }}>Premium Entertainment</span>
          <h1 className="font-display text-5xl md:text-7xl font-bold text-white mb-6 animate-slideUp" style={{ animationDelay: '0.4s' }}>
            Book <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#d4a843] to-[#f0c060]">Top Artists</span><br />
            For Your Events
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mb-10 animate-slideUp" style={{ animationDelay: '0.6s' }}>
            India&apos;s most trusted platform for booking verified DJs, Singers, Comedians, and Bands. Elevate your event with world-class performances.
          </p>
          <div className="flex flex-wrap justify-center gap-4 animate-slideUp" style={{ animationDelay: '0.8s' }}>
            <Link href="/artists" className="btn btn-primary btn-lg">
              Explore Artists
            </Link>
            <button onClick={() => openBooking()} className="btn btn-ghost btn-lg">
              Book Now
            </button>
          </div>
        </div>
      </section>

      {/* INTENT SECTION - WHAT ARE YOU LOOKING FOR? */}
      <section className="section bg-[#10101a] relative">
        <div className="container">
          <div className="section-header">
            <h2 className="section-title">What Are You Looking For?</h2>
            <div className="divider-gold"></div>
            <p className="section-subtitle mt-md">Find the perfect entertainment tailored to your specific event type.</p>
          </div>

          <div className="grid-4">
            <Link href="/artists?category=Singer" className="card group relative overflow-hidden h-[240px] flex flex-col items-center justify-center text-center p-6">
              <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=1000&auto=format&fit=crop')] bg-cover bg-center opacity-20 group-hover:opacity-30 transition-opacity duration-500"></div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
              <FaMusic className="text-4xl text-[#d4a843] mb-4 relative z-10 group-hover:scale-110 transition-transform duration-300" />
              <h3 className="text-xl font-bold text-white relative z-10">Wedding Artist</h3>
              <p className="text-sm text-gray-400 mt-2 relative z-10">Make your special day unforgettable</p>
            </Link>

            <Link href="/artists?category=DJ" className="card group relative overflow-hidden h-[240px] flex flex-col items-center justify-center text-center p-6">
              <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1470229722913-7c090be5c520?q=80&w=1000&auto=format&fit=crop')] bg-cover bg-center opacity-20 group-hover:opacity-30 transition-opacity duration-500"></div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
              <FaGlassCheers className="text-4xl text-[#d4a843] mb-4 relative z-10 group-hover:scale-110 transition-transform duration-300" />
              <h3 className="text-xl font-bold text-white relative z-10">Party DJ</h3>
              <p className="text-sm text-gray-400 mt-2 relative z-10">Keep the dance floor packed all night</p>
            </Link>

            <Link href="/artists?category=Comedian" className="card group relative overflow-hidden h-[240px] flex flex-col items-center justify-center text-center p-6">
              <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1511578314322-379afb476865?q=80&w=1000&auto=format&fit=crop')] bg-cover bg-center opacity-20 group-hover:opacity-30 transition-opacity duration-500"></div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
              <FaBuilding className="text-4xl text-[#d4a843] mb-4 relative z-10 group-hover:scale-110 transition-transform duration-300" />
              <h3 className="text-xl font-bold text-white relative z-10">Corporate Event</h3>
              <p className="text-sm text-gray-400 mt-2 relative z-10">Professional acts for your team</p>
            </Link>

            <Link href="/artists?category=Band" className="card group relative overflow-hidden h-[240px] flex flex-col items-center justify-center text-center p-6">
              <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1459749411175-04bf5292ceea?q=80&w=1000&auto=format&fit=crop')] bg-cover bg-center opacity-20 group-hover:opacity-30 transition-opacity duration-500"></div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
              <FaGraduationCap className="text-4xl text-[#d4a843] mb-4 relative z-10 group-hover:scale-110 transition-transform duration-300" />
              <h3 className="text-xl font-bold text-white relative z-10">College Fest</h3>
              <p className="text-sm text-gray-400 mt-2 relative z-10">High energy bands and performers</p>
            </Link>
          </div>
        </div>
      </section>

      {/* FEATURED ARTISTS */}
      <section className="section bg-[#0a0a0f]">
        <div className="container">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="section-title mb-2">Featured Artists</h2>
              <div className="w-16 h-1 bg-gradient-to-r from-[#d4a843] to-[#f0c060] rounded-full"></div>
            </div>
            <Link href="/artists" className="text-[#d4a843] hover:text-[#f0c060] font-medium hidden md:flex items-center gap-2">
              View All Artists <span aria-hidden="true">&rarr;</span>
            </Link>
          </div>

          {loading ? (
            <div className="grid-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="artist-card h-[400px] skeleton"></div>
              ))}
            </div>
          ) : (
            <div className="grid-4">
              {featuredArtists.map((artist) => (
                <div key={artist.id} className="artist-card">
                  {artist.isExclusive && <span className="artist-card-badge">Exclusive</span>}
                  <div className="artist-card-image">
                    {/* Fallback image logic for dummy data since we don't have actual files */}
                    <img 
                      src={artist.category === 'DJ' ? 'https://images.unsplash.com/photo-1571266028243-3716f02d2d2e?q=80&w=500&auto=format&fit=crop' :
                           artist.category === 'Singer' ? 'https://images.unsplash.com/photo-1516280440502-12f8650f9689?q=80&w=500&auto=format&fit=crop' :
                           artist.category === 'Band' ? 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=500&auto=format&fit=crop' :
                           'https://images.unsplash.com/photo-1493225457124-a1a2a5f590db?q=80&w=500&auto=format&fit=crop'
                      } 
                      alt={artist.name} 
                    />
                  </div>
                  <div className="artist-card-body">
                    <div className="artist-card-category">{artist.category}</div>
                    <h3 className="artist-card-name">{artist.name}</h3>
                    <div className="artist-card-meta">
                      <span className="flex items-center gap-1"><FaStar className="text-[#d4a843]" /> {artist.rating}</span>
                      <span>•</span>
                      <span>{artist.location}</span>
                    </div>
                    <div className="artist-card-actions mt-4">
                      <button onClick={() => openBooking(artist)} className="btn btn-primary btn-sm flex-1">Book Now</button>
                      <Link href={`/artists`} className="btn btn-secondary btn-sm">Profile</Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          <div className="mt-8 text-center md:hidden">
            <Link href="/artists" className="btn btn-secondary">
              View All Artists
            </Link>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="section-sm bg-[#14141f] border-y border-[rgba(255,255,255,0.05)]">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div className="flex flex-col items-center p-6 card-glass">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#d4a843]/20 to-transparent flex items-center justify-center mb-4 border border-[#d4a843]/30">
                <FaCheckCircle className="text-2xl text-[#d4a843]" />
              </div>
              <h4 className="font-bold text-lg mb-2 text-white">Verified Artists</h4>
              <p className="text-sm text-gray-400">All artists are personally vetted for quality and professionalism.</p>
            </div>
            
            <div className="flex flex-col items-center p-6 card-glass">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#d4a843]/20 to-transparent flex items-center justify-center mb-4 border border-[#d4a843]/30">
                <FaStar className="text-2xl text-[#d4a843]" />
              </div>
              <h4 className="font-bold text-lg mb-2 text-white">Premium Quality</h4>
              <p className="text-sm text-gray-400">Only the best entertainment for your premium events.</p>
            </div>

            <div className="flex flex-col items-center p-6 card-glass">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#d4a843]/20 to-transparent flex items-center justify-center mb-4 border border-[#d4a843]/30">
                <FaMusic className="text-2xl text-[#d4a843]" />
              </div>
              <h4 className="font-bold text-lg mb-2 text-white">Hassle-Free Booking</h4>
              <p className="text-sm text-gray-400">Seamless process from inquiry to final performance.</p>
            </div>

            <div className="flex flex-col items-center p-6 card-glass">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#d4a843]/20 to-transparent flex items-center justify-center mb-4 border border-[#d4a843]/30">
                <FaPhoneAlt className="text-xl text-[#d4a843]" />
              </div>
              <h4 className="font-bold text-lg mb-2 text-white">24/7 Support</h4>
              <p className="text-sm text-gray-400">Dedicated event managers to ensure everything goes perfectly.</p>
            </div>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="section bg-[#0a0a0f]">
        <div className="container">
          <div className="section-header">
            <span className="section-tag">Client Reviews</span>
            <h2 className="section-title mt-4">Trusted By Thousands</h2>
            <div className="divider-gold"></div>
          </div>

          <div className="grid-3">
            {testimonials.map((t) => (
              <div key={t.id} className="card p-8 flex flex-col h-full relative">
                <div className="text-4xl text-[rgba(212,168,67,0.15)] absolute top-6 right-8 font-serif">"</div>
                <div className="stars mb-4">
                  {[...Array(t.rating)].map((_, i) => <FaStar key={i} />)}
                </div>
                <p className="text-gray-300 italic mb-6 flex-1 text-sm leading-relaxed">"{t.content}"</p>
                <div className="flex items-center gap-4 mt-auto">
                  <div className="w-12 h-12 rounded-full bg-[#1a1a2e] flex items-center justify-center text-[#d4a843] font-bold border border-[#d4a843]/30">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-white text-sm">{t.name}</h4>
                    <p className="text-xs text-gray-500">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CALL TO ACTION BANNER */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-[#1a1408] to-[#0f0e1a] z-0"></div>
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1492684223066-81342ee5ff30?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center opacity-10 mix-blend-overlay"></div>
        <div className="container relative z-10 text-center">
          <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to Make Your Event <span className="text-[#d4a843]">Unforgettable?</span>
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto mb-10">
            Let's discuss your event requirements and find the perfect artist that fits your budget and vision.
          </p>
          <button onClick={() => openBooking()} className="btn btn-primary btn-lg px-12">
            Let's Have a Quick Discussion
          </button>
        </div>
      </section>

      {/* Booking Modal */}
      {modalOpen && <BookingModal onClose={() => setModalOpen(false)} artistName={selectedArtist?.name} artistId={selectedArtist?.id} />}
    </>
  );
}
